import cv2
import numpy as np
# from sklearn.cluster import KMeans


def solution(image_path):
# Load the image
  image = cv2.imread(image_path)
  
  image = cv2.pyrMeanShiftFiltering(image , 30 , 40)

  # kernel = np.array([[0, -1, 0],[-1, 7, -1],[0, -1, 0]])

  # image = cv2.filter2D(image, -1, kernel)

  # cv2.imshow('Sharp Image',image)
  # cv2.waitKey(0)
  # cv2.destroyAllWindows()

  image_hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

  # Extract the hue channel
  hue_channel = image_hsv[:, :, 0]
  sat_channel = image_hsv[:, :, 1]
  value_channel = image_hsv[:, :, 2]

  # Display the original image and the hue channel
  # cv2.imshow('Saturation Channel', sat_channel)
  # cv2.imshow('Hue Channel', hue_channel)
  # cv2.imshow('Value Channel', value_channel)
  # cv2.waitKey(0)
  # cv2.destroyAllWindows()

  test = hue_channel.copy()
  l,m = test.shape
  for i in range(0,l):
      for j in range(0,m):
          if(test[i][j]<=35 and sat_channel[i][j]>=90 and value_channel[i][j]>=90):
              test[i][j] = 255
          else:
              test[i][j] = 0
  test = np.stack([test, test, test], axis = -1)
  return test
